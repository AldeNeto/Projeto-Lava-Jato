
function handleRegister(event) {
    event.preventDefault();
  
    const nome = document.getElementById("nome").value;
    const dataNascimento = document.getElementById("dataNascimento").value;
    const cpf = document.getElementById("cpf").value;
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;
  
    fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nome, dataNascimento, cpf, email, senha }),
    })
      .then((res) => res.json())
      .then((data) => {
        alert(data.message);
        window.location.href = "login.html"; 
      })
      .catch((err) => console.error(err));
  }
  
 
 
function handleLogin(event) {
  event.preventDefault();
  const email = document.getElementById("loginEmail").value;
  const senha = document.getElementById("loginSenha").value;

  
  const users = JSON.parse(localStorage.getItem("users")) || [];

  
  const user = users.find(user => user.email === email && user.senha === senha);

  if (user) {
    alert(`Bem-vindo, ${user.nome}!`);
    window.location.href = "agendamento.html"; 
  } else {
    alert("E-mail ou senha incorretos. Tente novamente.");
  }
}


function handleRecover() {
  const email = prompt("Digite seu e-mail para recuperar a senha:");
  
  if (email) {
    
    const users = JSON.parse(localStorage.getItem("users")) || [];
    const user = users.find(user => user.email === email);

    if (user) {
      alert(`Sua senha é: ${user.senha}`);
    } else {
      alert("E-mail não encontrado. Verifique se está correto.");
    }
  }
}


function isValidCPF(cpf) {
  if (!cpf || cpf.length !== 11 || /^[0-9]+$/.test(cpf) === false) {
    return false;
  }

  let soma = 0;
  let resto;

  
  for (let i = 1; i <= 9; i++) {
    soma += parseInt(cpf.substring(i - 1, i)) * (11 - i);
  }
  resto = (soma * 10) % 11;
  if (resto === 10 || resto === 11) resto = 0;
  if (resto !== parseInt(cpf.substring(9, 10))) return false;

  
  soma = 0;
  for (let i = 1; i <= 10; i++) {
    soma += parseInt(cpf.substring(i - 1, i)) * (12 - i);
  }
  resto = (soma * 10) % 11;
  if (resto === 10 || resto === 11) resto = 0;

  return resto === parseInt(cpf.substring(10, 11));
}


function handleRegister(event) {
  event.preventDefault();

  const nome = document.getElementById("nome").value.trim();
  const dataNascimento = document.getElementById("dataNascimento").value;
  const cpf = document.getElementById("cpf").value.trim();
  const email = document.getElementById("email").value.trim();
  const senha = document.getElementById("senha").value;

  
  if (!isValidCPF(cpf)) {
    alert("CPF inválido. Verifique e tente novamente.");
    return;
  }

  
  const users = JSON.parse(localStorage.getItem("users")) || [];
  if (users.some(user => user.cpf === cpf || user.email === email)) {
    alert("Usuário com esse CPF ou E-mail já cadastrado.");
    return;
  }

  
  const newUser = { nome, dataNascimento, cpf, email, senha };
  users.push(newUser);
  localStorage.setItem("users", JSON.stringify(users));

  alert("Cadastro realizado com sucesso!");
  window.location.href = "login.html"; 
}


function handleAgendamento(event) {
 
  event.preventDefault();

 
  const placa = document.getElementById('placa').value;
  const modelo = document.getElementById('modelo').value;
  const servico = document.getElementById('servico').value;

  
  if (placa && modelo && servico) {
    
    const agendamento = {
      placa: placa,
      modelo: modelo,
      servico: servico,
      data: new Date().toLocaleString() 
    };

   
    let agendamentos = JSON.parse(localStorage.getItem('agendamentos')) || [];

    
    agendamentos.push(agendamento);

    
    localStorage.setItem('agendamentos', JSON.stringify(agendamentos));

    
    document.getElementById('mensagem').innerHTML = "<p style='color: green;'>Agendamento realizado com sucesso!</p>";

  
    document.getElementById('agendamentoForm').reset();
  } else {
    
    document.getElementById('mensagem').innerHTML = "<p style='color: red;'>Por favor, preencha todos os campos!</p>";
  }
}


function listarAgendamentos() {
  let agendamentos = JSON.parse(localStorage.getItem('agendamentos')) || [];
  if (agendamentos.length > 0) {
    console.log("Lista de agendamentos:", agendamentos);
  } else {
    console.log("Nenhum agendamento encontrado.");
  }
}

listarAgendamentos();

  