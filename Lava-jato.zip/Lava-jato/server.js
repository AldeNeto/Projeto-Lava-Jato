const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


app.use(express.static(path.join(__dirname, "public")));


const usersFilePath = path.join(__dirname, "data", "users.json");


app.post("/api/register", (req, res) => {
  const { nome, dataNascimento, cpf, email, senha } = req.body;

  const users = JSON.parse(fs.readFileSync(usersFilePath, "utf-8"));
  if (users.find((user) => user.email === email)) {
    return res.status(400).json({ error: "E-mail já cadastrado!" });
  }

  users.push({ nome, dataNascimento, cpf, email, senha });
  fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
  res.json({ message: "Usuário cadastrado com sucesso!" });
});


app.post("/api/login", (req, res) => {
  const { email, senha } = req.body;

  const users = JSON.parse(fs.readFileSync(usersFilePath, "utf-8"));
  const user = users.find((user) => user.email === email && user.senha === senha);

  if (!user) {
    return res.status(401).json({ error: "E-mail ou senha inválidos!" });
  }

  res.json({ message: "Login realizado com sucesso!" });
});


app.post("/api/recover", (req, res) => {
  const { email } = req.body;

  const users = JSON.parse(fs.readFileSync(usersFilePath, "utf-8"));
  const user = users.find((user) => user.email === email);

  if (!user) {
    return res.status(404).json({ error: "Usuário não encontrado!" });
  }

  res.json({ message: `Sua senha é: ${user.senha}` });
});


app.listen(PORT, () => {
  console.log(`Servidor rodando em: http://localhost:${PORT}`);
});
